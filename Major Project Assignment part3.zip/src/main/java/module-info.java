module com.example.attendancetrackerproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.attendancetrackerproject to javafx.fxml;
    exports com.example.attendancetrackerproject;
}